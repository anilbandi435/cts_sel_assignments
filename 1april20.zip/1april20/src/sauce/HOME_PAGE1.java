package sauce;


	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;

	public class HOME_PAGE1 {
		WebDriver dr1;
		By login_link = By.linkText("Log in");
		By verify_title = By.linkText("title");
		public HOME_PAGE1(WebDriver dr) 
		{
			this.dr1=dr;
		}
		 

		
		 public void click_login_link()
		 {
			 dr1.findElement(login_link).click();

	}



		public void verify_title() {
			dr1.findElement(verify_title).click();
			
		}

}
