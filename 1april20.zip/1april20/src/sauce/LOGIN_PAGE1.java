package sauce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LOGIN_PAGE1 {

	WebDriver dr2;

	By eid = By.id("user-name");
	By pwd = By.id("password");
	By login_btn = By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");

	public  LOGIN_PAGE1(WebDriver dr) {

	this.dr2=dr;
	}
	public void enterUser(String emailid)
	{
	dr2.findElement(eid).sendKeys(emailid);

	}

	public void enter_pass(String password)
	{
	dr2.findElement(pwd).sendKeys(password);


	}
	public void click_login()
	{
	dr2.findElement(login_btn).click();

	}

	public void verify_product()
	{


	String product=dr2.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
	if (product.equals("Products"))
	System.out.println("product matches");
	else
	System.out.println("product doesnt matches");
	}


	public void do_login(String emailid, String password) {
	this.enterUser(emailid);
	this.enter_pass(password);
	this.click_login();
	this.verify_product();
	}

	}



