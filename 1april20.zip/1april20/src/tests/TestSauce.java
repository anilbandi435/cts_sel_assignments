package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BASE_CLASS.utilities;
import excel_io_operations.excel_io_arr;
import sauce.HOME_PAGE1;
import sauce.LOGIN_PAGE1;

public class TestSauce extends excel_io_arr {
	WebDriver dr;
	HOME_PAGE1 hp;
	LOGIN_PAGE1 lp;
	product_page pp;
	String url="http://www.saucedemo.com";

	@BeforeClass
   public void Get_data() {
   
		get_test_data();
   }
	@BeforeMethod
	public void launch_browser() {
		dr= utilities.launch_browser("chrome", url);
		hp = new HOME_PAGE1(dr);
		lp = new LOGIN_PAGE1(dr);
		pp = new product_page(dr);
	}
	  @Test(dataProvider="login_data")
	  public void Login(String username,String pwd,String exp_pn) {
		  
		  hp.verify_title();
		  lp.do_login(username,pwd);
		  String act_pn = pp.get_productname();
		  System.out.println(act_pn);
		Assert.assertEquals(act_pn,exp_pn);
		  System.out.println("login-successful");
	  }
	@DataProvider(name="login_data") 
	public String[][] provide_data(){
		return testdata;
	}
	 
	
	@AfterClass

	public void close()
	{
	dr.close();
	}

	}






