package TESTNG_2;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

public class dataprovider_login_xl extends excel_io_arr {
	basic_testlogin test;
  @Test(dataProvider = "login_data")
  public void logintest(String eid , String pwd, String exp_eid) {
	  test = new basic_testlogin();
	  String a_eid = test.login(eid,pwd);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(a_eid,exp_eid);
	  sa.assertAll();
  }

  @DataProvider(name="login_data")
  public String provide_data() {
    String testdata = "anilbandi533@gmail.com";
	return testdata;
  }
  @BeforeClass
  public void get_data() {
	  get_test_data();
  }


	// TODO Auto-generated method stub
	
}

}
