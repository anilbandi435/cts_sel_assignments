package TESTNG_2;

public class basic_testlogin {

	public String login(String eid, String pwd) {
		String a_result;
		WebDriver dr = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		dr.get("https://demowebshop.tricentis.com/login");
		// TODO Auto-generated method stub
		dr.findelEment(By.xpath("//input[@class='email']")).sendKeys(eid);
		dr.findelEment(By.xpath("//input[@class='password']")).sendKeys(pwd);
		dr.findelEment(By.xpath("//input[@value='log in']")).click();
		String a_eid = dr.findElement(By.xpath("//div[@class='header-links]//child::li[1]/a")).getText();
		dr.close();
		return a_eid;
	}

}
