/*package tests;

import org.openqa.selenium.WebDriver;

public class product_page{
	
	
	public product_page(WebDriver dr) {
		// TODO Auto-generated constructor stub
	}
	public String get_productname() {
	
		return null;
	}

}*/
