package sauce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class product_page {
	WebDriver dr1;
	public void productpage(WebDriver dr) {
	this.dr1=dr;
	}
	public void verify_text(String expLabel) {
	String actLabel=dr1.findElement(By.className("product_label")).getText();
	 Assert.assertEquals(actLabel, expLabel);
	 {
	 System.out.println("Label matches");
	 }
	}
	public void click_atc() {
	dr1.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button")).click();
	}
	public void click_c(){
	dr1.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span")).click();

	}


}
