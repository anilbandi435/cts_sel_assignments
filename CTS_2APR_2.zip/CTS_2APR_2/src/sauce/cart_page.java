package sauce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class cart_page {
	public class cartpage {
		WebDriver dr2;
		public cartpage(WebDriver dr) {
		this.dr2=dr;
		}
		public void verify_name(String expname) {
		String actname=dr2.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		 Assert.assertEquals(actname, expname);
		 {
		 System.out.println("name matches");
		 }
		}public void verify_price(String expprice) {
		String actprice=dr2.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/div")).getText();
		 Assert.assertEquals(actprice, expprice);
		 {
		 System.out.println("price matches");
		 }
		}
	}
}



