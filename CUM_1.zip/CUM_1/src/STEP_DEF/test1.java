package STEP_DEF;




	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.Assert;

	import cucumber.api.java.en.Given;
	import cucumber.api.java.en.Then;
	import cucumber.api.java.en.When;

	public class test1 {
	WebDriver dr;
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	System.setProperty("webdriver.chrome.driver","chromedriver.exe" );
	   dr= new ChromeDriver();
	   dr.get("http://demowebshop.tricentis.com/");
	   dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	   }

	@When("^User enters login data and clicks ok button$")
	public void user_enters_login_data_and_clicks_ok_button() throws Throwable {

	dr.findElement(By.xpath("//input[@class='email']")).sendKeys("anilbandi533@gmail.com");
	dr.findElement(By.xpath("//input[@class='password']")).sendKeys("anilbandi8790@410");
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	   
	}

	@Then("^Homepage is displayed$")
	public void homepage_is_displayed() throws Throwable {
	String a_eid = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	   // Write code here that turns the phrase above into concrete actions
	String exp_eid = "anilbandi533@gmail.com";
	Assert.assertEquals(a_eid, exp_eid);
	{
	 System.out.println("Label matches");
	 }
	}
}
