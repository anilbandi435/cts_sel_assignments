package sauce;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class TestSauce {
	WebDriver dr;
	HOME_PAGE1 hp;
	LOGIN_PAGE1 lp;

	@BeforeClass

	public void launchbrowser()
	{
	System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
	dr = new ChromeDriver();
	dr.get("http://www.saucedemo.com");
	hp= new HOME_PAGE1(dr);
	lp = new LOGIN_PAGE1(dr);
	}
	  @Test
	  public void f() {
	 hp.verify_title();
	 lp.do_login("standard_user", "secret_sauce");
	  }

	@AfterClass

	public void close()
	{
	dr.close();
	}

	}




