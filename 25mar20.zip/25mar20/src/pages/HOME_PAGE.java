package pages;
import org.openqa.selenium.by;
public class HOME_PAGE {
	WebDriver dr1;
	By login_link = By.linkText("Log in");
	By register_link = By.linkText("Register");

	public HOME_PAGE(WebDriver dr) 
	{
		this.dr1=dr;
	}
	 

	public void click_register_link()
	 {
		 dr1.findElement(register_link).click();
	 }
	 public void click_login_link()
	 {
		 dr1.findElement(login_link).click();
	 }
}
