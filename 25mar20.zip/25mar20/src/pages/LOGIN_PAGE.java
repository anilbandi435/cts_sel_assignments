package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LOGIN_PAGE {
	WebDriver dr2;
	By eid = By.id("email");
	By pwd = By.id("password");
    By login_btn = By.xpath("//input[@value='Log in']");
    public LOGIN_PAGE(WebDriver dr)
    {
    	this.dr2= dr;
    }
    
    public void enter_email_id(String emailid)
    {
    	dr2.findElement(eid).sendKeys(emailid);
    }
    public void enter_password(String password)
    {
    	dr2.findElement(pwd).sendKeys(password);
    }
    public void click_login_btn()
    {
    	dr2.findElement(login_btn).click();
    }
    public void do_login(String emailid, String password) {
    	this.enter_email_id(emailid);
    	this.enter_password(password);
    	this.click_login_btn();
    }
}


}
