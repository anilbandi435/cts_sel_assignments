package pages;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class NewTest {
	WebDriver dr;
	HOME_PAGE hp;
	LOGIN_PAGE lp;
	 @Test
	  public void logintest1() {
		  hp.click_login_link();
		  lp.do_login("anilbandi533@gmail.com", "anilbandi8790@410");
	  }
 
 
  @BeforeClass
  public void launchbrowser() {
	  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		//at pages.NewTest.launchbrowser(NewTest.java:22)

	  dr = new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/");
	  hp = new HOME_PAGE(dr);
	  lp = new LOGIN_PAGE(dr);
  }
  
 
}


}
