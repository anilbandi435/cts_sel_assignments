package TEST_RUNNER;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
/*@CucumberOptions(features="FEATURES",tags= "@ROUND1,@ROUND2", glue="STEP_DEF")*/
//tags= "@ROUND1,@ROUND2",
@CucumberOptions(features="FEATURES",glue="STEP_DEF")
public class testrunner extends AbstractTestNGCucumberTests {

}
