package KWDFW;

public class TEST {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		excel_operations2 excel= new excel_operations2();
		//excel.write_excel(0, 1, "STEP");
		excel.write_excel2(8, 9, "selenium");
		//excel.write_excel3(3, 3, "login");
		}

		}


