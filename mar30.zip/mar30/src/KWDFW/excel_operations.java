package KWDFW;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {
	String filename = "\"C:\\Users\\HP\\Desktop\\excel\\KWDFW_FILE.xlsx\"", sheetname="KEYWORD";
	  public String read_excel(int row, int col)
	{  String s=null;


	try {
	File f =new File(filename);
	    FileInputStream fis = new FileInputStream(f);
	    XSSFWorkbook wb = new XSSFWorkbook(fis);
	    XSSFSheet sh = wb.getSheet(sheetname);
	    XSSFRow r = sh.getRow(row);
	    XSSFCell c = r.getCell(col);
	    s = c.getStringCellValue();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}return(s);

	}
	}
