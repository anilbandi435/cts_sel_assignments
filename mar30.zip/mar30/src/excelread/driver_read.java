package excelread;

public class driver_read {
public static void main(String[]args) {
	String x, y, z;
	excel_read1 excel = new excel_read1();
	for(int r=1;r<=6;r++) {
		x=excel.read_excel(r, 3);
		y=excel.read_excel(r, 4);
		z=excel.read_excel(r, 5);
		System.out.println(x + y + z);
	}
}
}
